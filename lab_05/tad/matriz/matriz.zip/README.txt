Para compilar no terminal LINUX, digite:

g++ -Wall -Wextra -std=c++17 main.cpp Matriz.cpp -o main

Para executar um dos testes, por exemplo, o teste in01,
voce deve digitar no terminal do LINUX:

./main < testes/in01 > resultado01.txt

Entao, um arquivo resultado01.txt sera gerado com a 
saida do seu programa. Voce pode entao testar o conteudo
do arquivo 'resultado01.txt' com o do arquivo 'out01' para
ver se eles sao os mesmo.
